# catsordogs
A simple script that tells you if the chosen image is that of a cat or a dog.
