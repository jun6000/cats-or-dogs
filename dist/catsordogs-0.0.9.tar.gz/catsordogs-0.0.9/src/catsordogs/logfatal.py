import sys

def logfatal(msg):
    print(msg)
    sys.exit(1)
